import mysql.connector
import os

def lambda_handler(event, context):
    try:
        # Database connection details
        host = os.environ['RDS_HOST']
        user = os.environ['RDS_USER']
        password = os.environ['RDS_PASSWORD']
        database = os.environ['RDS_DATABASE']
        
        # Connect to RDS instance
        connection = mysql.connector.connect(
            host=host,
            user=user,
            password=password,
            database=database
        )
        cursor = connection.cursor()
        
        # Sample Query
        cursor.execute("SELECT NOW();")
        result = cursor.fetchone()
        print("Current time from RDS:", result)
        
        # Close connections
        cursor.close()
        connection.close()
        return {
            "statusCode": 200,
            "body": f"Successfully connected to RDS: {result}"
        }
    except mysql.connector.Error as err:
        print("Error:", err)
        return {
            "statusCode": 500,
            "body": f"Error connecting to RDS: {err}"
        }

